import React from "react";
import  ViewVendorTable from './viewVendorTable'
import BackTheme from "../BackTheme";



const ViewVendorTableComponents =()=>{
   
    return(   
        <>
     
    <BackTheme/>
        <div style={{marginTop:'100px',marginRight:'15px',marginBottom:'50px'}}>

         <ViewVendorTable/>
        </div>
        <div>
     
   
        </div>
 
  
     
        </>
    )}


    export default ViewVendorTableComponents;